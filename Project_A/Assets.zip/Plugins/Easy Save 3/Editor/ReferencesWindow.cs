﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;
using ES3Internal;

namespace ES3Editor
{
	public class ReferencesWindow : SubWindow
	{


		public ReferencesWindow(EditorWindow window) : base("References", window){}

		public override void OnGUI()
		{
			
		}
	}

}
