




//////////////////////////////////// About the Asset /////////////////////////////////////////////

//Hi! This is Life Hacker. I am a 3d artist currently expanding my knowlege in blender. 

//I have this low poly scifi gun for you. Its free to use. Just mention my name in your project if possible 

// You can visit www.lifehacker8.com to know more about me. you can contact me there as well if you are having any problems.


/////////////////////////////////// Model Description ////////////////////////////////////////////
///

// NOTE - There are 2 models in this package. One has baked textures that means there is only one material on the model and is not customizable. Other one is not baked and has seperate materials which is fully customizable. Enjoy.


/*Vertices - 1,714
Edges - 3453
Faces - 1665
Triangles - 3410*/






// Thanks You!