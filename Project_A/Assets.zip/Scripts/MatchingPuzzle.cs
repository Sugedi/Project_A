using UnityEngine;

public class MatchingPuzzle : MonoBehaviour
{
    public GameObject target;
    public PuzzleDoor door;

}
