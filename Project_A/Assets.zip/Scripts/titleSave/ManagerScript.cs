using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ManagerScript : MonoBehaviour
{
    public int maxHP;
    public int attackDamage;
    public bool bossAClear;

}
