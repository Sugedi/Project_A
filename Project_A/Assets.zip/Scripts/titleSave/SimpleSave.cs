using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SimpleSave : MonoBehaviour
{
    public GameObject managerScript;
    public void Save()
    {
        ManagerScript script = managerScript.GetComponent<ManagerScript>();
        
    }
}
